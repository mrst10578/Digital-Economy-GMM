Original-data-only reproduction package. Historical 47-country/2005-2022 original source workbook; original two System GMM models and selected matched Difference GMM diagnostics. It is not proof of causal spillovers.

Raw workbook SHA256: 474d5525a37ecfbb424c9dd25d832a9ffa6eed1942bd4f4900454204810d215b

Separate PDF/DOCX available through the ChatGPT conversation, not embedded in this archive. No extended/new data included.
